import paho.mqtt.client as mqtt
from pymongo import MongoClient
import pymongo

connect = MongoClient("mongodb+srv://rushikesh:aaiot@cluster0.bzocrti.mongodb.net/?retryWrites=true&w=majority")
print("Connected Successfully ")

MONGO_DB = connect.projectdb
MONGO_COLLECTION = MONGO_DB.users
MONGO_DATETIME_FORMAT = "%d/%m/%Y %H:%M:%S"

MQTT_ADDRESS = '192.168.0.102'
MQTT_USER = 'project'
MQTT_PASSWORD = 'diot1234'
MQTT_TOPIC1 = 'sensor/temperature'
MQTT_TOPIC2 = 'sensor/hearbeat'

print("Result code:")
print("0: Connection successful")
print("1: Connection refused – incorrect protocol version")
print("2: Connection refused – invalid client identifier")
print("3: Connection refused – server unavailable")
print("4: Connection refused – bad username or password")
print("5: Connection refused – not authorized")
print("6-255: Currently unused.")
print("-------------------------------------")


def on_connect(client, userdata, flags, rc):
    """ The callback for when the client receives a CONNACK response from the server."""
    print('Connected with result code:  ' + str(rc))
    client.subscribe(MQTT_TOPIC1)
    

def on_message(client, userdata, msg):
    """The callback for when a PUBLISH message is received from the server."""
    print(msg.topic + ' ' + str(msg.payload))
    print("Storing")
    #now = datetime.now()
    try:
        document = {
            "topic": msg.topic,
            "payload": msg.payload.decode(),
            #"timestamp": int(now.timestamp()),
            #"datetime": now.strftime(MONGO_DATETIME_FORMAT),
            }
        
        MONGO_COLLECTION.insert_one(document)
        print("Saved in Mongo document")
            
    except Exception as ex:
            print(ex)


def main():
    mqtt_client = mqtt.Client()
    mqtt_client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
    mqtt_client.on_connect = on_connect
    mqtt_client.on_message = on_message

    mqtt_client.connect(MQTT_ADDRESS, 1883)
    mqtt_client.loop_forever()


if __name__ == '__main__':
    print('___MQTT to Mongodb___')
    main()

